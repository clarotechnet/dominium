const fields = {
  enabled: document.querySelector('#enabled'),
  baseUrl: document.querySelector('#baseUrl'),
  token: document.querySelector('#token'),
  collectorId: document.querySelector('#collectorId'),
  status: document.querySelector('#status'),
};

async function load() {
  const value = await chrome.storage.local.get([
    'dominiumCloudEnabled', 'dominiumCloudBaseUrl',
    'dominiumCollectorToken', 'dominiumCollectorId',
  ]);
  fields.enabled.checked = value.dominiumCloudEnabled === true;
  fields.baseUrl.value = value.dominiumCloudBaseUrl || '';
  fields.token.value = value.dominiumCollectorToken || '';
  fields.collectorId.value = value.dominiumCollectorId || 'central-toa';
}

document.querySelector('#save').addEventListener('click', async () => {
  fields.status.textContent = 'Salvando…';
  const baseUrl = fields.baseUrl.value.trim().replace(/\/+$/, '');
  if (fields.enabled.checked && !/^https:\/\/[a-z0-9.-]+\.workers\.dev$/i.test(baseUrl)) {
    fields.status.textContent = 'Use o endereço HTTPS workers.dev publicado.';
    return;
  }
  await chrome.storage.local.set({
    dominiumCloudEnabled: fields.enabled.checked,
    dominiumCloudBaseUrl: baseUrl,
    dominiumCollectorToken: fields.token.value.trim(),
    dominiumCollectorId: fields.collectorId.value.trim() || 'central-toa',
  });
  const response = await chrome.runtime.sendMessage({ action: 'cloud_bridge_status' });
  if (!response?.configured) {
    fields.status.textContent = 'Salvo, mas falta endereço ou chave.';
    return;
  }
  try {
    const health = await chrome.runtime.sendMessage({
      action: 'bridge_fetch', path: '/cloud/health', options: {},
    });
    fields.status.textContent = health?.ok && health?.data?.ok
      ? 'Ponte online. Mantenha o TOA aberto.'
      : 'Configuração salva; ponte ainda não respondeu.';
  } catch {
    fields.status.textContent = 'Configuração salva; ponte ainda não respondeu.';
  }
});

load();
